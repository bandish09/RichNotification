//
//  NotificationService.swift
//  NotificationService
//
//  Created by Deyan Aleksandrov on 1/30/18.
//  Copyright © 2018 centroida. All rights reserved.
//

import UserNotifications

/*
 {
     "aps": {
         "alert": {
             "title": "Push Notifications Test2",
             "body": "Sample image with actions."
         },
         "sound": "default",
         "badge": 1,
         "mutable-content":1,
        "category": "call",
         "attachment-url": "https://s3.amazonaws.com/uifaces/faces/twitter/follettkyle/128.jpg"
     }
 }

 {
     "aps": {
         "alert": {
             "title": "Push Notifications Test2",
             "body": "Sample image with actions."
         },
         "sound": "default",
         "badge": 1,
         "mutable-content":1,
        "category": "feedback",
         "attachment-url": "https://s3.amazonaws.com/uifaces/faces/twitter/follettkyle/128.jpg"
     }
 }

 */

class NotificationService: UNNotificationServiceExtension {

    var contentHandler: ((UNNotificationContent) -> Void)?
    var bestAttemptContent: UNMutableNotificationContent?
    var isLocal = true
    
    func getAttachment() -> UNNotificationAttachment? {
        NSLog("load local image")
        if let strPath = Bundle.main.path(forResource: "128.jpg", ofType: "") {
            let fURL = URL(fileURLWithPath: strPath)
            do {
                let attachment = try UNNotificationAttachment(identifier: "picture", url: fURL, options: nil)
                return attachment
            }
            catch {
                NSLog("Unexpected error: \(error).")
                return nil
            }
        }
        
        NSLog("128.jpg not found")
        return nil
    }
    
    override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void)
    {
        NSLog("---------- withContentHandler")
        
        self.contentHandler = contentHandler
        bestAttemptContent = (request.content.mutableCopy() as? UNMutableNotificationContent)
        
        guard let bestAttemptContent = bestAttemptContent, // 1. Make sure bestAttemptContent is not nil
            let apsData = bestAttemptContent.userInfo["aps"] as? [String: Any], // 2. Dig in the payload to get the
            let attachmentURLAsString = apsData["attachment-url"] as? String, // 3. The attachment-url
            let attachmentURL = URL(string: attachmentURLAsString) // 4. And parse it to URL
        else { return }
        
        if isLocal {
            if let attachment = getAttachment() {
                bestAttemptContent.attachments = [attachment]
                contentHandler(bestAttemptContent)
            }
        }
        else {
            // 5. Download the image and pass it to attachments if not nil
            downloadImageFrom(url: attachmentURL) { (attachment) in
                if attachment != nil {
                    bestAttemptContent.attachments = [attachment!]
                    contentHandler(bestAttemptContent)
                }
            }
        }
        
        
    }
    
    override func serviceExtensionTimeWillExpire() {
        // Called just before the extension will be terminated by the system.
        // Use this as an opportunity to deliver your "best attempt" at modified content, otherwise the original push payload will be used.
        if let contentHandler = contentHandler, let bestAttemptContent = bestAttemptContent {
            contentHandler(bestAttemptContent)
        }
    }
}

// MARK: - Helper Functions
extension NotificationService {

    /// Use this function to download an image and present it in a notification
    ///
    /// - Parameters:
    ///   - url: the url of the picture
    ///   - completion: return the image in the form of UNNotificationAttachment to be added to the bestAttemptContent attachments eventually
    private func downloadImageFrom(url: URL, with completionHandler: @escaping (UNNotificationAttachment?) -> Void) {
        NSLog("download remote image")
        let task = URLSession.shared.downloadTask(with: url) { (downloadedUrl, response, error) in
            // 1. Test URL and escape if URL not OK
            guard let downloadedUrl = downloadedUrl else {
                completionHandler(nil)
                return
            }

            // 2. Get current's user temporary directory path
            var urlPath = URL(fileURLWithPath: NSTemporaryDirectory())
            // 3. Add proper ending to url path, in the case .jpg (The system validates the content of attached files before scheduling the corresponding notification request. If an attached file is corrupted, invalid, or of an unsupported file type, the notification request is not scheduled for delivery. )
            let uniqueURLEnding = ProcessInfo.processInfo.globallyUniqueString + ".jpg"
            urlPath = urlPath.appendingPathComponent(uniqueURLEnding)

            // 4. Move downloadedUrl to newly created urlPath
            try? FileManager.default.moveItem(at: downloadedUrl, to: urlPath)
            NSLog("url = \(urlPath.absoluteString)")
            // 5. Try adding getting the attachment and pass it to the completion handler
            do {
                let attachment = try UNNotificationAttachment(identifier: "picture", url: urlPath, options: nil)
                completionHandler(attachment)
            }
            catch {
                completionHandler(nil)
            }
        }
        task.resume()
    }
}
