//
//  AppDelegate.swift
//  unicorner
//
//  Created by Deyan Aleksandrov on 1/19/18.
//  Copyright © 2018 centroida. All rights reserved.
//

import UIKit
import UserNotifications

enum RNCategoryNames: String {
    case Feedback = "feedback"
    case Call = "call"
}

enum RNActions: String {
    case Save = "Save"
    case Like = "Like"
    case Accept = "Accept"
    case Reject = "Reject"
}

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        registerForPushNotifications()
        registerPushCategories()
        NSLog("----------------- launchOptions=  \(launchOptions?.debugDescription ?? "")")
        return true
    }

    func registerPushCategories() {
        // cate-1
        let likeAction = UNNotificationAction(identifier: RNActions.Like.rawValue, title: RNActions.Like.rawValue, options: [])
        let saveAction = UNNotificationAction(identifier: RNActions.Save.rawValue, title: RNActions.Save.rawValue, options: [])
        let defaultCategory = UNNotificationCategory(identifier: RNCategoryNames.Feedback.rawValue,
                                                     actions: [likeAction, saveAction],
                                                     intentIdentifiers: [],
                                                     options: [])
        
        // cate-2
        let acceptAction = UNNotificationAction(identifier: RNActions.Accept.rawValue, title: RNActions.Accept.rawValue, options: [])
        let rejectAction = UNNotificationAction(identifier: RNActions.Reject.rawValue, title: RNActions.Reject.rawValue, options: [])
        let callCategory = UNNotificationCategory(identifier: RNCategoryNames.Call.rawValue,
                                                     actions: [acceptAction, rejectAction],
                                                     intentIdentifiers: [],
                                                     options: [])
        
        // Register the category.
        UNUserNotificationCenter.current().setNotificationCategories([defaultCategory, callCategory])
    }
    
    func registerForPushNotifications() {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
            (granted, error) in
            print("Permission granted: \(granted)")
            // 1. Check if permission granted
            guard granted else { return }
            // 2. Attempt registration for remote notifications on the main thread
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }
   
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let userInfo = notification.request.content.userInfo
        
        // Print full message.
        NSLog(userInfo.debugDescription)
        
        // Change this to your preferred presentation option
        completionHandler(UNNotificationPresentationOptions.alert)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void)
    {
        
        switch RNActions(rawValue: response.actionIdentifier) {
        case .Accept:
            NSLog("------ Handle accept action identifier")
        case .Reject:
            NSLog("----- Handle like reject identifier")
        case .Like:
            NSLog("----- Handle like action identifier")
        case .Save:
            NSLog("----- Handle save action identifier")
        default:
            NSLog("----- No custom action identifiers chosen")
        }
        
        // Make sure completionHandler method is at the bottom of this func
        completionHandler()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        // 1. Convert device token to string
        let tokenParts = deviceToken.map { data -> String in
            return String(format: "%02.2hhx", data)
        }
        let token = tokenParts.joined()
        // 2. Print device token to use for PNs payloads
        NSLog("Device Token: \(token)")
    }

    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        // 1. Print out error if PNs registration not successful
        NSLog("Failed to register for remote notifications with error: \(error)")
    }
}
