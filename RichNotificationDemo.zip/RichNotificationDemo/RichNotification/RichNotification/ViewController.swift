//
//  ViewController.swift
//  unicorner
//
//  Created by Deyan Aleksandrov on 1/19/18.
//  Copyright © 2018 centroida. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var unicornImageView: UIImageView!
    @IBOutlet weak var unicornName: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

